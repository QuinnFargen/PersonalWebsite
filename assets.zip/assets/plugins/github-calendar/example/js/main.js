GitHubCalendar(".calendar", "IonicaBizau", {
    responsive: true
});
